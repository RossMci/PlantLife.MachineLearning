package com.example.android.plantlifeapp;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class popularPlantsAdapter extends RecyclerView.Adapter<popularPlantsAdapter.ViewHolder> {
    private ArrayList<Bakery> bakeryList;
    Context context;
    Activity activity;

    public popularPlantsAdapter(Context context,ArrayList<Bakery> bakeryList) {
        this.context = context;
        this.bakeryList = bakeryList;
        this.activity = activity;
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
//        private TextView name;
//        private  TextView description;
//        private ImageView Icon;
        private TextView image;



        public ViewHolder(final  View view){
            super(view);
//            name=view.findViewById(R.id.nameTextView);
//            description=view.findViewById(R.id.descriptionTextView);
//            Icon=view.findViewById(R.id.itemimageView);
            image=view.findViewById(R.id.nameTextView);
        }

    }








    @NonNull
    @Override
    public popularPlantsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View valueView= LayoutInflater.from(parent.getContext()).inflate(R.layout.side_row_layout,parent,false);
        return new popularPlantsAdapter.ViewHolder(valueView);
    }


    @Override
    public void onBindViewHolder(@NonNull popularPlantsAdapter.ViewHolder holder, int position) {
//        String name = bakeryList.get(position).getName();
//        String description= bakeryList.get(position).getDescription();
        String image= bakeryList.get(position).getImage();
//        holder.name.setText(name);
//        holder.description.setText(description);
//        holder.image.setText(image);
    }

    @Override
    public int getItemCount() {
        return bakeryList.size();
    }
}

