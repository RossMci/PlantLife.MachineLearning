package com.example.android.plantlifeapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.android.plantlifeapp.databinding.ActivityMainBinding;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private RecyclerView examplePlantsRecyclerView;
    private RecyclerView PopularSelectionsRecyclerView;
    private ArrayList<Bakery> bakery=new ArrayList<>();
    com.example.android.plantlifeapp.MyAdapter adapter;
    com.example.android.plantlifeapp.popularPlantsAdapter adapter2;
    Menu myMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        NavigationView navigationView = findViewById(R.id.nav_view);
//        Menu menu = navigationView.getMenu();
//        menu.findItem(R.id.login).setVisible(false);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setIcon(R.drawable.ic_home_black_24dp);

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.action_bar_layout);



        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.camera,R.id.mySnapGarden, R.id.mySnapsFragment,R.id.login,R.id.registerFragment)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);
        examplePlantsRecyclerView = findViewById(R.id.examplePlantsRecyclerView);
        PopularSelectionsRecyclerView=findViewById(R.id.PopularSelectionsRecyclerView);

        // setting the layout of the recycler
      PopularSelectionsRecyclerView.setLayoutManager( new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, true));
        PopularSelectionsRecyclerView.setItemAnimator(new DefaultItemAnimator());

        examplePlantsRecyclerView.setLayoutManager( new LinearLayoutManager(this));
        examplePlantsRecyclerView.setItemAnimator(new DefaultItemAnimator());
        setBakeryRecipes();
        adapter = new com.example.android.plantlifeapp.MyAdapter(this,bakery);
        adapter2 = new com.example.android.plantlifeapp.popularPlantsAdapter(this,bakery);
//
        PopularSelectionsRecyclerView.setAdapter(adapter2);
        examplePlantsRecyclerView.setAdapter(adapter);






////        NavigationView navigationView = findViewById(R.id.nav_view);
////        Menu menu = navigationView.getMenu();
//        MenuItem menuItem = menu.findItem(R.id.login);
//
//        if(menuItem==menu.findItem(R.id.login)){
//            menu.findItem(R.id.login).setVisible(false);
//            menu.getItem(R.id.registerFragment).setVisible(true);

        }

//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.bottom_nav_menu, menu);
//        myMenu = menu;
//        MenuItem item = menu.findItem(R.id.login);
//        if (item != null) {
//            item.setVisible(true);
//        }
//        return true;
//    }
//
//    public void onCheckedChanged() {
//
//        NavigationView navigationView = findViewById(R.id.nav_view);
//        myMenu = navigationView.getMenu();
//        MenuItem menuItem = myMenu.findItem(R.id.login);
//        if(myMenu != null) {
////            if (menuItem == button1) {
//                myMenu.findItem(R.id.login).setVisible(false);
//                myMenu.findItem(R.id.login).setEnabled(false);
////            }
//        }
//    }
//
//    public boolean onOptionsItemSelected (MenuItem item){
//        switch (item.getItemId()){
//            case R.id.login:
//                break;
//
//            case R.id.registerFragment:
//                break;
//        }
//        return true;
//    }


    private void setBakeryRecipes() {
        bakery.add(new Bakery("bun","Its lovely","hi"));
        bakery.add(new Bakery("cake","Its lovely","hi"));
        bakery.add(new Bakery("waffle","Its lovely","hi"));
        bakery.add(new Bakery("pancake","Its lovely","hi"));

    }




}