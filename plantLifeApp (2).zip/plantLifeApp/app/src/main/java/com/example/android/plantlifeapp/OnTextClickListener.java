package com.example.android.plantlifeapp;

public interface OnTextClickListener {
    void onTextClick(Bakery data);
}
