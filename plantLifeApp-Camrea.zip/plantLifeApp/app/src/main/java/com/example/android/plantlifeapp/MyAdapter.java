package com.example.android.plantlifeapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.android.plantlifeapp.Bakery;
import com.example.android.plantlifeapp.R;
import com.example.android.plantlifeapp.ui.plantDescription.descriptionFragment;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>  {
    private ArrayList<Bakery> bakeryList;
    Context context;
    Activity activity;

    public MyAdapter(Context context,ArrayList<Bakery> bakeryList) {
        this.context = context;
        this.bakeryList = bakeryList;
        this.activity = activity;
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView name;
        private  TextView description;
        private ImageView Icon;
        private TextView image;



        public ViewHolder(final  View view){
            super(view);
            name=view.findViewById(R.id.nameTextView);
            description=view.findViewById(R.id.descriptionTextView);
            Icon=view.findViewById(R.id.itemimageView);
            image=view.findViewById(R.id.nameTextView);
        }

    }








    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View valueView= LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout,parent,false);
        return new ViewHolder(valueView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String name = bakeryList.get(position).getName();
        String description= bakeryList.get(position).getDescription();
        String image= bakeryList.get(position).getImage();
        holder.name.setText(name);
        holder.description.setText(description);
        holder.image.setText(image);
    }

    @Override
    public int getItemCount() {
        return bakeryList.size();
    }


//    class RecipeHolder extends RecyclerView.ViewHolder {
//
//
//        TextView nameTextView;
//        TextView descTextView;
//        TextView imageTextView;
//
//        // methods use to set the value in the description layout file
//        public RecipeHolder(@NonNull View itemView) {
//            super(itemView);
//
//            nameTextView = itemView.findViewById(R.id.nameTextView);
//            descTextView = itemView.findViewById(R.id.descriptionTextView);
//            imageTextView = itemView.findViewById(R.id.Label_descriptionTextView);
////            recipeImageView = itemView.findViewById(R.id.recipeImageView);
//
//
////            This click will open recipe detail activity....
//            itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    String str = nameTextView.getText().toString();
//                    String str2 = descTextView.getText().toString();
//                    String str3 = imageTextView.getText().toString();
//                    Intent intent = new Intent(context, descriptionFragment.class);
//                    intent.putExtra("nameTextView", str);
//                    intent.putExtra("descTextView", str2);
//                    intent.putExtra("prepTextView", str3);
////                    intent.putExtra("recipe", String.valueOf(recipeList.get(getAdapterPosition())));
////                    intent.putExtra("ingredient", String.valueOf(ingredientList.get(getAdapterPosition())));
//
//                    // Ross if you have ingredients and steps you coudl also add those to teh intent using putParecelabelArrayExtra(...)
//                    context.startActivity(intent);
//                }
//            });
//
//        }
    }
//}


