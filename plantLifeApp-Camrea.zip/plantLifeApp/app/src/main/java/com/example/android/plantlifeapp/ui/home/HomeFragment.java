package com.example.android.plantlifeapp.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.android.plantlifeapp.Bakery;
//import com.example.android.plantlifeapp.MyAdapter;
import com.example.android.plantlifeapp.R;
import com.example.android.plantlifeapp.databinding.ActivityMainBinding;
import com.example.android.plantlifeapp.databinding.FragmentHomeBinding;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private FragmentHomeBinding binding;
    private RecyclerView examplePlantsRecyclerView;
    private RecyclerView PopularSelectionsRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private  ArrayList<Bakery> bakery=new ArrayList<>();
    com.example.android.plantlifeapp.MyAdapter adapter;
    com.example.android.plantlifeapp.popularPlantsAdapter adapter2;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

//        final TextView textView = binding.textHome;
//        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });


        examplePlantsRecyclerView = (RecyclerView) root.findViewById(R.id.examplePlantsRecyclerView);
        PopularSelectionsRecyclerView=(RecyclerView) root.findViewById(R.id.PopularSelectionsRecyclerView);

        // setting the layout of the recycler
        PopularSelectionsRecyclerView.setLayoutManager( new LinearLayoutManager(getActivity().getApplicationContext(),LinearLayoutManager.HORIZONTAL, true));
        PopularSelectionsRecyclerView.setItemAnimator(new DefaultItemAnimator());

        examplePlantsRecyclerView.setLayoutManager( new LinearLayoutManager(getActivity().getApplicationContext()));
        examplePlantsRecyclerView.setItemAnimator(new DefaultItemAnimator());
        setBakeryRecipes();
        adapter = new com.example.android.plantlifeapp.MyAdapter(getActivity().getApplicationContext(),bakery);
        adapter2 = new com.example.android.plantlifeapp.popularPlantsAdapter(getActivity().getApplicationContext(),bakery);

        PopularSelectionsRecyclerView.setAdapter(adapter2);

        examplePlantsRecyclerView.setAdapter(adapter);
        return root;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void setBakeryRecipes() {
        bakery.add(new Bakery("bun","Its lovely","hi"));
        bakery.add(new Bakery("cake","Its lovely","hi"));
        bakery.add(new Bakery("waffle","Its lovely","hi"));
        bakery.add(new Bakery("pancake","Its lovely","hi"));

    }
}